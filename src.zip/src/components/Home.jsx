import React from 'react'
import tv_onair_logo from '../assets/tv_onair_logo.png'

const Home = () => {
  return (
    <div id="home" className='h-screen w-full bg-customYellow'>
        <div className='max-w-screen-lg mx-auto flex flex-col items-center justify-center h-full px-2'>
            <img src={tv_onair_logo} alt="TVONAIR" className="w-64 md:w-96 lg:w-1/2" />
        </div>
    </div>
  )
}

export default Home