import React, { useEffect, useRef, useState } from "react";
import tv_onair_logo from "./assets/tv_onair_logo.png";
import rocket_icon from "./assets/rocket_icon.png";
import jam from "./assets/jam.png";
import insta_logo from "./assets/insta_logo.png";
import gmail_logo from "./assets/gmail_logo.png";
import { useState } from 'react'
import { FaBars, FaTimes } from "react-icons/fa";
import { useRef } from "react";
import { Link, Element } from "react-scroll";
import { useLayoutEffect } from "react";
import gsap from "gsap";
import AOS from "aos";
import "aos/dist/aos.css";
import "./App.css";

function App() {
  const [nav, setNav] = useState(false);
  const [animated, setAnimated] = useState(false);

  const closeNav = () => {
    setNav(false);
    setTimeout(() => {
      setAnimated(false);
    }, 500);
  };

  const toggleNav = () => {
    setNav(!nav);
    setAnimated(true);
  };
  
  const home = useRef(null);
  const about = useRef(null);
  const divisions = useRef(null);

  // divisions
  const showTeamMembers = (category) => {
    // Update the section with member images
    const teamMembersContainer = document.getElementById("teamMembers");
    const selectedCategory = teamData[category] || {
      coordinators: [],
      members: [],
    };

    teamMembersContainer.innerHTML = "";

    // Show coordinators at the top
    for (const [
      index,
      coordinator,
    ] of selectedCategory.coordinators.entries()) {
      if (coordinator.name) {
        // Use random image link for coordinator
        const coordinatorImageLink = getRandomImageLink();
        let coordinatorElement = `
        <div class="p-4 md:w-1/3 w-full flex flex-col text-center items-center">
          <div class="h-full flex flex-col items-center text-center">
            <img alt="team" class="flex-shrink-0 rounded-lg w-201 h-201 object-cover object-center mb-4 ${
              selectedCategory.coordinators.length === 2 ? "md:-mx-2" : ""
            }" src="${coordinatorImageLink}">
            <div class="w-full">
              <h2 class="title-font font-medium text-lg text-gray-900">${
                coordinator.name
              }</h2>
              <h3 class="text-gray-500 mb-3">${coordinator.title}</h3>
            </div>
          </div>
        </div>
      `;
        if (selectedCategory.coordinators.length === 1) {
          // Saat hanya ada 1 koordinator, gunakan lebar penuh
          coordinatorElement = coordinatorElement.replace(
            "md:w-1/3",
            "md:w-full"
          );
        } else if (selectedCategory.coordinators.length === 2) {
          // Saat ada 2 koordinator, ubah menjadi 4 kolom
          if (index === 0 || index === 1) {
            coordinatorElement = coordinatorElement.replace(
              "md:w-1/3",
              "md:w-1/2"
            );
          }
          // Letakkan gambar pada kolom ke-2 dan ke-3 (indeks 1 dan 2)
          if (index === 1) {
            coordinatorElement = coordinatorElement.replace(
              "md:w-1/2",
              "md:w-1/4"
            );
            coordinatorElement = coordinatorElement.replace(
              "items-center",
              "items-center md:ml-auto md:mr-auto"
            );
          }
        }
        teamMembersContainer.innerHTML += coordinatorElement;
      }
    }

    // Show members
    for (const member of selectedCategory.members) {
      const memberElement = `
      <div class="p-4 md:w-1/3 w-full flex flex-col text-center items-center">
      </div>
    `;
      teamMembersContainer.innerHTML += memberElement;
    }

    // Update the section with the list of members
    const listAnggotaContainer = document.getElementById(
      "listAnggotaTableBody"
    );
    listAnggotaContainer.innerHTML = "";

    for (const member of selectedCategory.members) {
      const memberElement = `<tr><td class="px-4 py-3 text-center">${member.name}</td></tr>`;
      listAnggotaContainer.innerHTML += memberElement;
    }
  };
  
  const teamData = {
    Visual: {
      coordinators: [
        { name: "ganjar mahmud ", title: "Coordinator" },
        { name: "ynag bener aja  ", title: "Coordinator" },
        { name: "rugi dongggg  ", title: "Coordinator" },
      ],
      members: [
        { name: "Tranter Jaskulski", title: "Founder & Specialist" },
        { name: "Abigail", title: "Founder & Specialist" },
        { name: "Jaskulski", title: "Founder & Specialist" },
      ],
    },
    Sponsor: {
      coordinators: [
        { name: "jokowi prabowo", title: "Coordinator" },
        { name: "si paling sponsor", title: "Coordinator" },
      ],
      members: [
        { name: "Anna Jagna", title: "Tired & M. Specialist" },
        { name: "Audrey Jagna", title: "Tired & M. Specialist" },
        { name: "Ava Jagna", title: "Tired & M. Specialist" },
      ],
    },
    Media_Relation: {
      coordinators: [{ name: "lan cai tek guh", title: "Coordinator" }],
      members: [
        { name: "Kenji Milton", title: "Team Member" },
        { name: "Kenji Milton", title: "Team Member" },
        { name: "Kenji Milton", title: "Team Member" },
      ],
    },
    // Add other categories and team members as needed
  };

  const getRandomImageLink = () => {
    // Example of a placeholder image link. Replace it with your actual image links.
    const imageLinks = [
      "https://picsum.photos/id/201/201/201",
      "https://picsum.photos/seed/picsum/201/201",
      "https://picsum.photos/201/201?grayscale",
      // Add more image links as needed
    ];

    // Return a random image link
    return imageLinks[Math.floor(Math.random() * imageLinks.length)];
  };

  // scroll animation
  useEffect(() => {
    AOS.init({duration: 2000});
  }, []);

  // const comp = useRef(null);
  // useLayoutEffect(() => {
  //   let ctx = gsap.context(() => {
  //     const t1 = gsap.timeline()
  //     t1.from("#intro-slider", {
  //       xPercent: "-100",
  //       duration: 1.3,
  //       delay: 0.3,
  //     }).from(["#content-1"], {
  //       opacity: 0,
  //       y: "+=30",
  //       stagger: 0.5,
  //     }). to(["#content-1"], {
  //       opacity: 100,
  //       delay: 0.3,
  //       stagger: 0.5,
  //     })
  //   }, comp)

  //   return () => ctx.revert()
  // },[])

  return (
    <div className="App">
      {/* Navbar */}
      <div className="flex justify-between items-center w-full h-20 px-4 bg-customBlue fixed z-10">
        <ul className="hidden md:flex px-8 items-center">
          <li className="mx-2 px-4 cursor-pointer uppercase font-medium text-white transition-transform duration-200 ease-in-out transform hover:scale-110">
            <Link
              to="home"
              smooth={true}
              offset={-200}
              duration={800}
              className="hover:text-gray-500 duration-200"
            >
              home
            </Link>
          </li>
          <li className="mx-2 px-4 cursor-pointer uppercase font-medium text-white transition-transform duration-200 ease-in-out transform hover:scale-110">
            <Link
              to="about"
              smooth={true}
              offset={200}
              duration={800}
              className="hover:text-gray-500 duration-200"
            >
              about us
            </Link>
          </li>
          <li className="mx-2 px-4 cursor-pointer uppercase font-medium text-white transition-transform duration-200 ease-in-out transform hover:scale-110">
            <Link
              to="divisions"
              smooth={true}
              offset={200}
              duration={800}
              className="hover:text-gray-500 duration-200"
            >
              divisions
            </Link>
          </li>
        </ul>

        {/* IconBar */}
        <div
          onClick={toggleNav}
          className="cursor-pointer pr-4 z-10 text-customDarkBlue md:hidden ml-auto transition-transform duration-200 ease-in-out transform hover:scale-110"
        >
          {nav ? <FaTimes size={35} /> : <FaBars size={35} />}
        </div>

        {/* Navbar Mobile/Responsive */}
        {nav && (
          <div className="navbar-mobile">
            <ul
              className={`flex flex-col justify-center items-center absolute top-0 right-0 w-full h-screen bg-gradient-to-b from-customBlue to-customYellow text-white text-xl transition-transform duration-500`}
            >
              <li className="px-4 cursor-pointer uppercase py-6">
                <Link
                  to="home"
                  smooth={true}
                  offset={-200}
                  duration={1000}
                  className="hover:text-gray-500 duration-200 scale-110"
                  onClick={closeNav}
                >
                  Home
                </Link>
              </li>
              <li className="px-4 cursor-pointer uppercase py-6">
                <Link
                  to="about"
                  smooth={true}
                  offset={-300}
                  duration={1000}
                  className="hover:text-gray-500 duration-200 scale-110"
                  onClick={closeNav}
                >
                  about us
                </Link>
              </li>
              <li className="px-4 cursor-pointer uppercase py-6">
                <Link
                  to="divisions"
                  smooth={true}
                  offset={200}
                  duration={1000}
                  className="hover:text-gray-500 duration-200 scale-110"
                  onClick={closeNav}
                >
                  divisions
                </Link>
              </li>
            </ul>
          </div>
        )}
      </div>

      {/* Home */}
      <Element name="home">
        <div ref={home} className="h-screen w-full relative bg-customYellow">
          <div className="max-w-screen-lg mx-auto flex items-center justify-center h-full relative">
            <img
              src={tv_onair_logo}
              alt="TVONAIR"
              className="w-64 md:w-72 lg:w-1/3 animate-bounce"
              data-aos="zoom-in"
            />
            <img
              src={rocket_icon}
              alt="Rocket"
              className="w-36 md:w-48 lg:w-1/5 absolute right-0 bottom-64 animate-pulse"
              data-aos="flip-left"
            />
            <img
              src={jam}
              alt="Clock"
              className="w-36 md:w-48 lg:w-1/5 absolute left-0 top-48 animate-pulse"
              data-aos="flip-right"
            />
          </div>
        </div>
      </Element>

      {/* About  */}
      <Element name="about">
        <div ref={about} className="h-screen w-full bg-gray-900 text-white">
          <div className="max-w-screen-lg mx-auto flex flex-col items-center justify-center h-full px-2">
            <div
              className="text-xl px-2 sm:text-2xl sm:px-4 md:text-3xl lg:text-4xl text-justify text-transparent bg-clip-text bg-gradient-to-r from-[#80EAE9] to-[#FFF57A] text-shadow-lg"
              data-aos="fade-up"
            >
              Media televisi yang berada di bawah naungan kampus Universitas
              Multimedia Nusantara, UMN TV membuat dan menyajikan beragam macam
              konten berkualitas melalui program redaksinya. UMN TV juga
              menghadirkan TVONAIR 9.0 sebagai jembatan untuk meperkenalkan UMN
              TV kepada internal maupun eksternal kampus, juga menambah wawasan
              terkait media kepada masyarakat.
            </div>
          </div>
        </div>
      </Element>

      {/* Divisions */}
      <Element name="divisions">

      </Element>

      {/* Footer */}
      <Element name="footer">
        <footer className="bg-customBlue h-48 w-full px-3 pb-2 text-center text-white">
          <div className="font-signature flex h-full flex-col md:flex-row items-center justify-around text-sm">
            {/* Left side: University information */}
            <div className="md:w-1/2 mb-4 md:mb-0">
              <p className="text-center md:text-left text-base mb-4">
                Universitas Multimedia Nusantara <br />
                Jl. Scientia Boulevard, Gading Serpong, <br />
                Tangerang, Banten, 15811, Indonesia.
              </p>
              <p className="text-center md:text-left mb-2">© 2024 TVONAIR.</p>
            </div>

            {/* Right side: Social media links */}
            <div className="flex gap-4 items-center">
              <a
                href="https://www.instagram.com/tv.onair/"
                className="inline-flex items-center text-base font-semibold transition-transform duration-300 ease-in-out hover:scale-105 hover:underline"
              >
                Instagram
                <img
                  className="ml-2 inline-block h-8 w-8"
                  src={insta_logo}
                  alt="Instagram logo"
                />
              </a>
              <a
                href="mailto:tv.onair9@gmail.com"
                className="inline-flex items-center text-base font-semibold transition-transform duration-300 ease-in-out hover:scale-105 hover:underline"
              >
                E-mail
                <img
                  className="ml-2 inline-block h-8 w-8"
                  src={gmail_logo}
                  alt="Gmail logo"
                />
              </a>
            </div>
          </div>
        </footer>
      </Element>
    </div>
  );
}

export default App;