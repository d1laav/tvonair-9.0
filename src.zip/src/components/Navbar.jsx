import React, { useState } from 'react'
import {FaBars, FaTimes } from "react-icons/fa"
// import { HashLink as Link } from "react-router-hash-link";

const Navbar = () => {
    const [nav, setNav] = useState(false);
    return (
        <div className="flex justify-between items-center w-full h-20 px-4 bg-customBlue fixed">
            <ul className='hidden md:flex px-8 items-center'>
                <li id='home' className='mx-2 px-4 cursor-pointer uppercase font-medium text-white transition-transform duration-200 ease-in-out transform hover:scale-110'>
                    <a href='/' className='hover:text-gray-500 duration-200'>home
                        {/* <Link
                            activeClass="active"
                            spy={true}
                            smooth={true}
                            offset={-70}
                            duration={500}
                            to="/"
                            activeClassName="selected"
                            >
                            home
                        </Link> */}
                    </a>
                </li>
                <li id='about' className='mx-2 px-4 cursor-pointer uppercase font-medium text-white transition-transform duration-200 ease-in-out transform hover:scale-110'>
                    <a href='About.jsx' className='hover:text-gray-500 duration-200'> about us
                        {/* <Link
                            activeClass="active"
                            spy={true}
                            offset={-70}
                            duration={500}
                            to="About"
                            activeClassName="selected"
                            >
                            about us
                        </Link> */}
                        {/* <Link to= '#about'>about us</Link> */}
                    </a>

                </li>
                <li id='divions' className='mx-2 px-4 cursor-pointer uppercase font-medium text-white transition-transform duration-200 ease-in-out transform hover:scale-110'>
                    <a href='/' className='hover:text-gray-500 duration-200'> Divisions
                        {/* <Link
                            activeClass="active"
                            spy={true}
                            offset={-70}
                            duration={500}
                            to="Divisions"
                            activeClassName="selected"
                            >
                            division
                        </Link> */}
                    </a>
                </li>
            </ul>
            <div onClick={() => setNav(!nav)} 
            className='cursor-pointer pr-4 z-10 text-customDarkBlue md:hidden ml-auto transition-opacity duration-300 ease-in-out opacity-75 hover:opacity-100'>
                {nav ? <FaTimes size={25} /> : <FaBars size={25} />}
            </div>

            {nav && (
              <ul className='flex flex-col justify-center items-center absolute top-0 left-0 w-full h-screen bg-gradient-to-b from-customBlue to-customYellow text-white'>
                <li className='px-4 cursor-pointer uppercase py-6'>home</li>
                {/* <li className='px-4 cursor-pointer uppercase py-6'>registration</li> */}
                <li className='px-4 cursor-pointer uppercase py-6'>about us</li>
                <li className='px-4 cursor-pointer uppercase py-6'>division</li>
            </ul>  
            )}
        </div>
    )
}

export default Navbar