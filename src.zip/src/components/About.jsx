import React from 'react'

const About = () => {
  return (
    <div id="about" className='h-screen w-full bg-gray-900 text-white'>
        <div className='max-w-screen-lg mx-auto flex flex-col items-center justify-center h-full px-2'>
            <div className='text-3xl md:text-4xl lg:text-4xl text-justify text-transparent bg-clip-text bg-gradient-to-r from-[#80EAE9] to-[#FFF57A] text-shadow-lg'>
              Media televisi yang berada di bawah naungan kampus Universitas Multimedia Nusantara, 
              UMN TV membuat dan menyajikan beragam macam konten berkualitas melalui program redaksinya. 
              UMN TV juga menghadirkan TVONAIR 9.0 sebagai jembatan untuk meperkenalkan UMN TV kepada 
              internal maupun eksternal kampus, juga menambah wawasan terkait media kepada masyarakat.
            </div>
        </div>
    </div>
  )
}

export default About